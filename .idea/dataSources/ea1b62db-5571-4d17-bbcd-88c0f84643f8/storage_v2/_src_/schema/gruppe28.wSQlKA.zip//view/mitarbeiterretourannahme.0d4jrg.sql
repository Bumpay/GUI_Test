create view mitarbeiterretourannahme as
select `gruppe28`.`einkauf`.`idEinkauf`                                                                    AS `Kassenbelegnummer`,
       `gruppe28`.`einkauf`.`datum`                                                                        AS `Kaufdatum`,
       case
           when to_days(curdate()) - to_days(`gruppe28`.`einkauf`.`datum`) > 30 then 'Nein'
           else 'Ja' end                                                                                   AS `Umtauschbar`,
       `a`.`name`                                                                                          AS `Artikel`,
       sum(if(`gruppe28`.`einkauf`.`idEinkauf` = `r`.`fEinkaufId` and `eha`.`fArtikelId` = `rha`.`fArtikelId` and
              `r`.`idRetour` = `rha`.`fRetourId`, `eha`.`menge` - `rha`.`menge`,
              `eha`.`menge`))                                                                              AS `Mengendifferenz Einkauf/Retour`
from ((((`gruppe28`.`einkauf` join `gruppe28`.`einkauf_has_artikel` `eha` on (`gruppe28`.`einkauf`.`idEinkauf` = `eha`.`fEinkaufId`)) join `gruppe28`.`artikel` `a` on (`eha`.`fArtikelId` = `a`.`idArtikel`)) left join `gruppe28`.`retour` `r` on (`gruppe28`.`einkauf`.`idEinkauf` = `r`.`fEinkaufId`))
         left join `gruppe28`.`retour_has_artikel` `rha` on (`a`.`idArtikel` = `rha`.`fArtikelId`))
where `eha`.`fArtikelId` = `rha`.`fArtikelId` and `r`.`idRetour` = `rha`.`fRetourId`
   or `r`.`fEinkaufId` is null
group by `gruppe28`.`einkauf`.`idEinkauf`, `a`.`name`
order by `gruppe28`.`einkauf`.`idEinkauf`;

