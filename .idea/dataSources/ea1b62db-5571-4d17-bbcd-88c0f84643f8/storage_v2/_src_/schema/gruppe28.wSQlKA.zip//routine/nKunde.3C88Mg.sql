create
    definer = root@localhost procedure nKunde(IN iNname varchar(20), IN iVname varchar(20), IN iPlz int(5),
                                              IN iOrt varchar(40), IN iStraße varchar(40), IN iHnummer int,
                                              IN iAzusatz varchar(5))
begin
    DECLARE idA int default null;

    START TRANSACTION ;

    IF EXISTS(SELECT idAnschrift FROM anschrift WHERE plz = iPlz AND ort = iOrt AND straße = iStraße AND hausnummer= iHnummer AND adresszusatz = iAzusatz) THEN
        SET idA = (SELECT idAnschrift FROM anschrift WHERE plz = iPlz AND ort = iOrt AND straße = iStraße AND hausnummer= iHnummer AND adresszusatz = iAzusatz);
    ELSE
        INSERT INTO anschrift (plz, ort, straße, hausnummer, adresszusatz)
        VALUES (iPlz, iOrt, iStraße, iHnummer, iAzusatz);
        SET idA = LAST_INSERT_ID();
    END IF;

    IF EXISTS(SELECT * FROM kunde WHERE nachname = iNname AND vorname = iVname AND fAnschriftId = idA) THEN
        SELECT 'Kunde existiert bereits' as 'Fehlermeldung';
        ROLLBACK ;
    ELSE
        INSERT INTO kunde (nachname, vorname, fAnschriftId)
        VALUES (iNname, iVname, idA);
        COMMIT ; -- wenn commit nicht da, auslesen mit SELECT zeigt anschrift und kunde an (DIRTY READ IN Repeatable Read einstellung)
    END IF;

end;

