create
    definer = root@localhost procedure artikelInBaumarkt(IN ort varchar(45), IN artikelId int, OUT oOrt varchar(45),
                                                         OUT oArtikel varchar(45), OUT oVerfuegbarkeit varchar(45))
begin
    START TRANSACTION;

    SELECT Baumarkt, IF(EXISTS(SELECT idArtikel FROM artikel WHERE artikel.idArtikel = artikelId), Artikel, 'Existiert nicht!') , Status INTO oOrt, oArtikel, oVerfuegbarkeit FROM kundesichtaufartikel
    JOIN artikel a on kundesichtaufartikel.Artikel = a.name
    WHERE a.idArtikel = artikelId
    AND Baumarkt LIKE ort;

end;

