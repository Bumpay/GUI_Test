create
    definer = root@localhost procedure calculateUmsatz(IN baumarktId int, OUT umsatz decimal(10, 2), OUT oBaumarktId int)
begin
    SELECT cast(if(SUM(EhA.menge * A.preis) IS NULL, 0, SUM(EhA.menge * A.preis)) as float), baumarkt.idBaumarkt INTO umsatz, oBaumarktId FROM Baumarkt
    LEFT JOIN Einkauf E on Baumarkt.idBaumarkt = E.fBaumarktId
    LEFT JOIN Einkauf_has_Artikel EhA on E.idEinkauf = EhA.fEinkaufId
    LEFT JOIN Artikel A on EhA.fArtikelId = A.idArtikel
    WHERE idBaumarkt = baumarktId;

    UPDATE baumarkt SET baumarkt.umsatz = umsatz WHERE idBaumarkt = baumarktId;

end;

