create view kundesichtaufartikel as
select `a`.`name`               AS `Artikel`,
       `a2`.`ort`               AS `Baumarkt`,
       case
           when `gruppe28`.`artikel_auf_lager`.`anzahl` = 0 then 'nicht vorrätig'
           when `gruppe28`.`artikel_auf_lager`.`anzahl` < 10 then 'nur wenige'
           else 'vorhanden' end AS `Status`,
       `a`.`beschreibung`       AS `beschreibung`
from (((`gruppe28`.`artikel_auf_lager` join `gruppe28`.`artikel` `a` on (`a`.`idArtikel` = `gruppe28`.`artikel_auf_lager`.`fArtikelId`)) join `gruppe28`.`baumarkt` `b` on (`gruppe28`.`artikel_auf_lager`.`fBaumarktId` = `b`.`idBaumarkt`))
         join `gruppe28`.`anschrift` `a2` on (`a2`.`idAnschrift` = `b`.`fAnschriftId`));

